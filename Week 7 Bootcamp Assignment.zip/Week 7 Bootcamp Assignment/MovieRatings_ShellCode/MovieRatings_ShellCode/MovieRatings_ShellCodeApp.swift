//
//  MovieRatings_ShellCodeApp.swift
//  MovieRatings_ShellCode
//
//  Created by Nicholas Candello on 1/11/24.
//

import SwiftUI

@main
struct MovieRatings_ShellCodeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
