import SwiftUI

/**
 RATINGCARDVIEW.SWIFT
 */
struct RatingCardView: View {
    /**
     INSTANCE VARIABLES
     - Movie/Rating to be displayed on this card. ( Movie )
     */
    
    // ADD CODE HERE
    
    /**
     YOUR UI
     - The actual implementation of a Card's UI will go here.
     - Since leaving a text review is optional, you will need a conditional text depending on whether or not
       the rating has a text review (evaluate the "myReview" field of the movie)
     */
    var body: some View {
        Text("YOUR UI HERE") // REPLACE WITH YOUR CODE
    }
}

#Preview {
    RatingCardView() // Once you have instance variables, you will need to add arguments here to see preview.
}
