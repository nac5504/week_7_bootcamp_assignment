import SwiftUI

/**
 RATINGSVIEW.SWIFT
 - This View appears when the sheet is presented from ContentView.
 */
struct RatingsView: View {
    /**
     INSTANCE VARIABLES
     - Variable storing all ratings. (SAME REFERENCE to ContentView's ratings variable) ( [Movie] )
     */
    
    // ADD CODE HERE
    
    /**
     YOUR UI
     - Display all ratings submitted.
     - For each rating, create a RatingCardView with a corresponding rating.
     */
    var body: some View {
        
        Text("UI CODE HERE") // REPLACE WITH YOUR CODE
        
    }
}

#Preview {
    RatingsView() // Once you have instance variables, you will need to add arguments here to see preview.
}
