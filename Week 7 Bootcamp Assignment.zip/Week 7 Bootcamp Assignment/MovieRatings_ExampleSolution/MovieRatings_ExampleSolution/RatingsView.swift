//
//  RatingsView.swift
//  MovieRatings
//
//  Created by Nicholas Candello on 9/20/23.
//

import SwiftUI

struct RatingsView: View {
    @Binding var ratings: [Movie]
    
    var body: some View {
        ScrollView {
            Text("My Ratings")
                .padding()
                .font(.largeTitle)
                .fontWeight(.heavy)
            VStack(alignment: .leading, spacing: 20) {
                ForEach(ratings) { movie in
                    RatingCardView(movie: movie)
                }
            }
        }.frame(width: UIScreen.main.bounds.size.width)
        .background(Color(red: 0.8, green: 0.8, blue: 0.8))
        
    }
}

#Preview {
    RatingsView(ratings: Binding.constant([Movie(title: "Back To The Future", year: "1985", description: "Eighties teenager Marty McFly is accidentally sent back in time to 1955, inadvertently disrupting his parents' first meeting and attracting his mother's romantic interest. Marty must repair the damage to history by rekindling his parents' romance and - with the help of his eccentric inventor friend Doc Brown - return to 1985.", image: "back_to_the_future", rating: 3, myReview: "Very Good movie. I love it.")]))
}
