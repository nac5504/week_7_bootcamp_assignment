//
//  RatingCardView.swift
//  MovieRatings_ExampleSolution
//
//  Created by Nicholas Candello on 1/11/24.
//

import SwiftUI

struct RatingCardView: View {
    let movie: Movie
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Image(movie.image)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 125)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding(5)
                VStack(alignment: .leading) {
                    Text(movie.title)
                        .font(.title3)
                        .bold()
                        .padding(.horizontal, 8)
                    
                    HStack {
                        Spacer()
                        Circle()
                            .foregroundStyle(.black)
                            .overlay(
                                Text("\(movie.rating!) / 5")
                                    .font(.title3)
                                    .foregroundStyle(.white)
                            )
                            .frame(width: 70)
                            .italic()
                    }
                }
            }
            if movie.myReview!.count > 0 {
                VStack(alignment: .leading, spacing: 5) {
                    Divider()
                        .padding(.bottom)
                    Text("Your Review: ")
                        .bold()
                        .italic()
                        .font(.title3)
                    
                    Text(movie.myReview!)
                }
            }
        }
        .frame(width: UIScreen.main.bounds.size.width*0.8, alignment: .leading)
        .padding(20)
        .background(.white)
        .cornerRadius(10)
        .padding(15)
        
    }
}

#Preview {
    RatingCardView(movie: Movie(title: "Back To The Future", year: "1985", description: "Eighties teenager Marty McFly is accidentally sent back in time to 1955, inadvertently disrupting his parents' first meeting and attracting his mother's romantic interest. Marty must repair the damage to history by rekindling his parents' romance and - with the help of his eccentric inventor friend Doc Brown - return to 1985.", image: "back_to_the_future", rating: 3, myReview: "Very Good movie. I love it."))
}
