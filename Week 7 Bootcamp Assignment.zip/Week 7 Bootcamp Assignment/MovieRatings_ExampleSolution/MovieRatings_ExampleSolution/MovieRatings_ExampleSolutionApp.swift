//
//  MovieRatings_ExampleSolutionApp.swift
//  MovieRatings_ExampleSolution
//
//  Created by Nicholas Candello on 1/11/24.
//

import SwiftUI

@main
struct MovieRatings_ExampleSolutionApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
